import React from 'react';

export default function MyFooter() {
  return (
    <footer className=" py-5 bg-light">
      <p className="text-center text-body-dark">&copy; 2024 SM VITA PG-DAC September '23 Group-3</p>
    </footer>
  );
};