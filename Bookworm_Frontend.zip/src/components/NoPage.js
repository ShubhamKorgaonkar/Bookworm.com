import React from 'react'

export default function NoPage() {
  return (
    <div>404 - Page Not Found</div>
  )
}
