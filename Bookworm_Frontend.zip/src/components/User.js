import React from 'react'
import MyForm from './MyForm'
import 'bootstrap/dist/css/bootstrap.min.css';

const User = () => {
  return (
    <div>
        <MyForm/>
    </div>
  )
}

export default User;
