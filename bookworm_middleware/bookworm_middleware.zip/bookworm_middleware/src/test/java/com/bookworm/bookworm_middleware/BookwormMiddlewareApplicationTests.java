package com.bookworm.bookworm_middleware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookwormMiddlewareApplicationTests {

	@Test
	void contextLoads() {
	}

}
